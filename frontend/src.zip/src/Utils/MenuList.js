export const MenuList = [
    {
      title: "Home",
      url: "/",
    },
    {
      title: "Floor Plans",
      url: "/features",
    },
    {
      title: "Photos",
      url: "/pricing",
    },
    {
      title: "Amenities",
      url: "/testimonials",
    },
    {
      title: "Video Tour",
      url: "/demo",
    },
    {
      title: "Map",
      url: "/demo",
    },
    {
      title: "Rent Room",
      url: "/demo",
    },
    {
      title: "Contact Us",
      url: "/demo",
    },
    {
      title: "Sign In",
      url: "/demo",
    },
  ];