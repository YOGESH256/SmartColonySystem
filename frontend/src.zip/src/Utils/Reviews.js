export const Reviews = [
    {
      desc : " Very friendly diverse community, a great deal of Amenities to offer, friendly staff, clean grounds. Family oriented. Just a great place to live. I have been here going on 9 years and I don't plan on moving anytime soon",
      name : "Soham"
    },
    {
        desc: '"Hello There2"',
        name : "Yogesh" 
    },
    {
        desc: '"Hello There3"',
        name : "Rohan" 
    },
    {
        desc: '"Hello There4"',
        name : "Meet"  
    },
    {
        desc: '"Hello There5"',
        name : "ABC"  
    }
  ];