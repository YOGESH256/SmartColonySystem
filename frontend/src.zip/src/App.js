
import React from 'react';
import { BrowserRouter, Switch, Route } from "react-router-dom";
import Navbar from './components/Navbar';
import rentalHome from './pages/rentalHome';
import videoTour from './pages/videoTour';
import FloorPlans from './pages/FloorPlans';

// import Main from "./pages/Main";
// import { Contactus } from "./pages/Contactus";
// import { Contact } from "./pages/Contact";
// import ServiceDetails from './pages/ServiceDetails';
import 'bootstrap/dist/css/bootstrap.min.css';
// import Accordian from './components/Accordian';
// import AboutWorker from './components/AboutWorker';
// import Amenities from './pages/Amenities'
import Mapbox from './pages/Mapbox'

function App() {
  return (
    <div className="App">
      <BrowserRouter>

        <Switch>
        <Route path='/' component={FloorPlans} />

        </Switch>
      </BrowserRouter>
    </div>
  );
}

export default App;
