import React , {useState , useEffect} from 'react'
import { Container, Row, Col , Button } from 'react-bootstrap'
import Header from  '../components/Amencomp/Header';
import ReactMapGL ,  {Marker, Popup} from 'react-map-gl';


import './Map.css'
import {Link} from 'react-router-dom'

const Mapbox = () => {
  const [selectedLocation, setSelectedLocation] = useState({})
  const [postalCode , setPostalCode] = useState('')
  const [coordinates , setCoordinates] = useState({
    latitude: 37.7577,
    longitude:-122.4376,
})

  const [viewport , setViewport] = useState({
    width:'100%',
    height:'100%',
    latitude: 37.7577,
    longitude:-122.4376 ,
    zoom: 8
  })

  useEffect(() => {



  } , [handleChange])




var handleChange =  async(e) => {
  e.preventDefault();

console.log(e.target[0].value)
const pin = e.target[0].value;




const lo =  await Promise.all([
    fetch(`http://open.mapquestapi.com/geocoding/v1/address?key=tdFMfs7paLPqAcweYs0mwFhsi7fqyhto&postalCode=${pin}`),
   ]).then(async([aa]) => {
    const a = await aa.json();
    return a;
  })
  .then((responseText) => {
    return (responseText.results[0].locations[0].latLng);

  }).catch((err) => {
    console.log(err);
  });
console.log(lo);
console.log(lo);
  setViewport({
        width:'100%',
        height:'100%',
        latitude: lo.lat,
        longitude: lo.lng,
        zoom: 12

      });


      setCoordinates({
        latitude: lo.lat,
        longitude: lo.lng,
      })
console.log(coordinates);

}








  return (
<>
<Header />
<Row className = "container ko ml-5 p-4 ">
<div className=" container">
<form onSubmit = {handleChange}>
<div className="form-group">
 <label >Postal code</label>
 <input type="text" className="form-control w-50" id="exampleInputEmail1"  placeholder="Enter Postal Code" value = {postalCode}  onChange = {(e) => setPostalCode(e.target.value)} />
 <small id="emailHelp" className="form-text text-muted">We'll never share your email with anyone else.</small>
</div>

<button type="submit"  className="btn btn-primary m-2">Submit</button>
</form>
</div>
</Row>
<div className = "container koo">


   <ReactMapGL
   mapStyle = 'mapbox://styles/yogeshkhatri/cks1qh67i2i9017lflkd0g3t6'
   mapboxApiAccessToken = 'pk.eyJ1IjoieW9nZXNoa2hhdHJpIiwiYSI6ImNrczFwb3VpZzF3MngycHBzdnVyY2JneGoifQ.5r167zpS6Z-kK7Y-xobAGA'
   {...viewport}
   onViewportChange = {(nextViewport) => setViewport(nextViewport)}
   >

      <Marker
     longitude ={coordinates.longitude}
     latitude= {coordinates.latitude}
     offsetLeft = {-20}
     offsetRight= {-10}
     >
     <p  role = "img"  onClick ={() => setSelectedLocation(coordinates)} className = "bounce">📌</p>
      </Marker>

      {selectedLocation.longitude === coordinates.longitude ?(
     <Popup
     onClose = {() => setSelectedLocation({})}
     closeonClick = {true}
     longitude = {coordinates.longitude}
     latitude = {coordinates.latitude}

     >

    Location

    </Popup>

   ):(
     false
   )}
   </ReactMapGL>


</div>

</>
  )
}

export default Mapbox
