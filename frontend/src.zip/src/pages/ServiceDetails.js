import React from "react";
import HowitWorks from '../components/HowitWorks';
import Reviews from '../components/Reviews';



export default function ServiceDetails() {
    return (
        <div className="services">
        <HowitWorks />
        <Reviews />


        </div>
    );
}
