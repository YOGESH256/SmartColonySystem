const imgs = {
    f1: require('../images/floorPlan/fl-p1.png').default,
    f2: require('../images/floorPlan/fl-p2.jpeg').default,
    f3: require('../images/floorPlan/fl-p3.jpeg').default,
    f4: require('../images/floorPlan/fl-p4.png').default,
}
export default imgs;