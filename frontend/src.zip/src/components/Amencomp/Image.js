import React from 'react'
import './Styles.css';
import { LinkContainer } from 'react-router-bootstrap'
import { Navbar, Nav, Container, NavDropdown } from 'react-bootstrap'

const Image = () => {
  return (
<>
<div className = "image-sv">
<div className = "text">
 <h1> SEVEN SPRINGS APARTMENT </h1>
</div>
</div>

</>
  )
}

export default Image
